import { test, expect } from '@playwright/test';
import users from '../creds/Users.js';
import LoginPage from '../pagesObject/LoginPage.js';
import InventoryPage from '../pagesObject/InventoryPage.js';
import CartPage from '../pagesObject/CartPage.js';
import CheckoutPage from '../pagesObject/CheckoutPage.js';

test( 'Performance User Journey', async ({page}) => {

    const login = new LoginPage(page);
    const addItem = new InventoryPage(page)
    const cartItems = new CartPage(page);
    const checkoutPage = new CheckoutPage(page);
    await page.goto('/');
    await login.userInput(users.Performance_User.username);
    await login.passwordInput(users.Performance_User.password);
    await login.login();
    await addItem.hamburgMenuClick();
    await addItem.resetAppStateClick();
    await addItem.sortProductsZtoA();
    await addItem.addFirstProductToCart();
    await addItem.clickOnCartButton();
    const productNames = await cartItems.getProductNames();
    await expect(productNames).toEqual(['Test.allTheThings() T-Shirt (Red)']);
    await cartItems.checkOutButtonClick();
    await checkoutPage.fillCheckOutInfo('MR', 'Ali', '123');
    await checkoutPage.continueCheckout();
    const overviewProductNames = await checkoutPage.getOverviewProductNames();
    await expect(overviewProductNames).toEqual(['Test.allTheThings() T-Shirt (Red)']);
    const total = await checkoutPage.getTotalPrice();
    await expect(total).toBe('Total: $17.27');
    await checkoutPage.finishCheckout();
    await expect(page.getByRole('heading', { name: 'Thank you for your order!' })).toBeVisible();
    await addItem.hamburgMenuClick();
    await addItem.resetAppStateClick();
    await addItem.clickOnLogoutButton();

});