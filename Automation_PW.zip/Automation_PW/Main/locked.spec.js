import { test, expect } from  '@playwright/test';
import LoginPage from '../pagesObject/LoginPage.js';
import users from '../creds/Users.js';

test ('Veryfy error msg for Locked_out_user', async ({page}) => 
   {
   const loginPage = new LoginPage(page);
   await page.goto('/');
   await loginPage.userInput(users.Locked_User.username);
   await loginPage.passwordInput(users.Locked_User.password);
   await loginPage.login();
   await expect(page.getByRole('alert')).toHaveText
   ('Epic sadface: Sorry, this user has been locked out.');
   }
);
