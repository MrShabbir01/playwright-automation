export default  class CartPage
{
    constructor(page)
    {
        this.page = page;
        this.productItemName = this.page.locator('.inventory_item_name');
        this.checkOut = this.page.getByRole('button',{ name : 'Checkout'});
    };

    async getProductNames()
    {
        return await this.productItemName.allTextContents();
    };

    async checkOutButtonClick()
    {
        await this.checkOut.click();
    };
};
