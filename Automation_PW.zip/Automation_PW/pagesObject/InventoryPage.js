export default class InventoryPage 
{    
  constructor(page)
  {
      this.page = page;

      this.hamburgerMenu = this.page.getByRole('button', {name : 'Open Menu'});
      this.resetAppState = this.page.getByText('Reset App State');
      this.logOut = this.page.getByRole('button', {name : 'Logout'});
      this.openCart = this.page.locator('.shopping_cart_link');

      this.sortingDropDown = this.page.locator('.product_sort_container');
  }

  async hamburgMenuClick() 
  {
    await this.hamburgerMenu.click();
  };

  async resetAppStateClick()
  {
    await this.resetAppState.click();
  };
  
  async addPrductToCart(productName)
  {
    const product = this.page
    .locator('.inventory_item')
    .filter({ hasText: productName });

    const addButton = product.getByRole('button', { name: 'Add to cart'});

    await addButton.click();

  };

  async clickOnCartButton()
  {
    await this.openCart.click();
  };

  async clickOnLogoutButton()
  {
    await this.logOut.click();
  };





  async sortProductsZtoA()
  {
    await this.sortingDropDown.selectOption('za');
  };


  async addFirstProductToCart()
  {
    const firstProduct = this.page.locator('.inventory_item').first();
    const addButton = firstProduct.getByRole('button', { name: 'Add to cart' });

    await addButton.click();
  };







};