export default class LoginPage
{
  constructor(page)
  {
    this.page = page;
    
    this.usernameField = this.page.locator('#user-name');
    this.passwordField = this.page.locator('#password');
    this.loginButton = this.page.getByRole('button', {name: 'Login'});
  }

  async userInput(username) 
  {
    await this.usernameField.fill(username);
  }
  
  async passwordInput(password)
  {
    await this.passwordField.fill(password);
  }
  
  async login()
  {
    await this.loginButton.click();
  }
  
};