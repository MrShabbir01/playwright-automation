export default class CheckoutPage
{
    constructor(page)
    {
        this.page = page;
        this.firstNameField = this.page.locator('#first-name');
        this.lastNameField = this.page.locator('#last-name');
        this.postalCodeField = this.page.locator('#postal-code');
        this.continueButton = this.page.getByRole('button', { name: 'Continue' });
                                        


        this.overviewProductNames = this.page.locator('.inventory_item_name');
        this.totalPrice = this.page.locator('.summary_total_label');
        this.finishButton = this.page.getByRole('button', { name: 'Finish' });



        this.successMessage = this.page.locator('.complete-header');




    };


    async fillCheckOutInfo(firstName, lastName , postalCode)
    {
        await this.firstNameField.fill(firstName);
        await this.lastNameField.fill(lastName);
        await this.postalCodeField.fill(postalCode);
    };

    async continueCheckout()
    {
        await this.continueButton.click();
    };

    async getOverviewProductNames()
    {
        return await this.overviewProductNames.allTextContents();
    };

    async getTotalPrice() 
    {
    return await this.totalPrice.textContent();
    };
     
    async finishCheckout()
    {
        await this.finishButton.click();
    };
    
    async verifyOrderSuccess()
    {
        await expect(this.successMessage).toHaveText('Thank you for your order!');
    };

};