const users =
{
    
    Locked_User:
    {
        username :'locked_out_user',
        password : 'secret_sauce'
    },
    
    
    Standard_User:
    {
        username : 'standard_user',
        password : 'secret_sauce'
    },
    
    Performance_User : 
    {
        username : 'performance_glitch_user',
        password : 'secret_sauce'
    }

};

export default users;

